package toefadm.service.AccountmanageService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import toefadm.dto.AccountManageDto.AgentDto;
import toefadm.mapper.AccountManageMapper.AgentMapper;

@Service
public class AgentServiceImpl  {
	
	@Autowired
	private AgentMapper agentMapper;
	
	public List<AgentDto> selectAgentList() throws Exception {
		return agentMapper.selectAgentList();
	}

}	

