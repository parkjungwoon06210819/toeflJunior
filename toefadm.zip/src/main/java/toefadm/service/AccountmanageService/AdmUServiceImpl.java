package toefadm.service.AccountmanageService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import toefadm.dto.AccountManageDto.AdmUDto;
import toefadm.mapper.AccountManageMapper.AdmUMapper;

@Service
public class AdmUServiceImpl{
	
	@Autowired
	private AdmUMapper admUMapper;
	
	public List<AdmUDto> selectAdmUList() throws Exception {
		return admUMapper.selectAdmUList();
	}


}	

