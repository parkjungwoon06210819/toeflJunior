package toefadm.service.HompageService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import toefadm.dto.HompageDto.NoticeDto.NewslaterDto;
import toefadm.mapper.HompageMapper.NewslaterMapper;

import java.util.List;

@Service
public class NewslaterServiceImpl {
	
	@Autowired
	private  NewslaterMapper  NewslaterMapper;
	
	public List<NewslaterDto> selectNeweslaterList() throws Exception {
		return  NewslaterMapper.selectNeweslaterList();
	}

}

