package toefadm.service.HompageService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import toefadm.dto.HompageDto.NoticeDto.NoticeDto;
import toefadm.dto.HompageDto.NoticeDto.NoticeParamsDto;
import toefadm.mapper.HompageMapper.NoticeMapper;


import java.util.List;

@Service
public class NoticetServiceImpl {
	
	@Autowired
	private NoticeMapper noticeMapper;
	
	public List<NoticeDto> selectNoticeList() throws Exception {
		return noticeMapper.selectNoticeList();
	}

	public List<NoticeParamsDto> findItemMainList(NoticeParamsDto params) {
		return noticeMapper.findItemMainList();
	}
}	

