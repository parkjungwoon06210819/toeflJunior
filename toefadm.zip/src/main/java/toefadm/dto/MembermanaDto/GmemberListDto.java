package toefadm.dto.MembermanaDto;

import lombok.Data;

@Data
public class GmemberListDto {
	private String dgmCode;
	private String dgmUserid;
	private String dgmName;
	private String dgmPasswowrd;
	private String dgmGroupType;
	private String dgmTopGroup;
	private String daadId;
	private String dacCode;
	private String bizRegno;
	private String dgmOfficeNum;
	private String dgmZipcode;
	private String dgmAddress;
	private String dgmAddress2;
	private String dgmUsername;
	private String dgmTel;
	private String dgmHp;
	private String mobileProvider;
	private String dgmFax;
	private String dgmEmail;
	private String dmState;
	private String joinDate;
	private String dgmRegDate;
	private String requestJoinPc;
	private String dgmOutDate;
	private String dgmMemo;
	private String testGroupCode;
	private String lastAccessTime;
	private String lastAccessIp;
	private String passwordSha2;

}
