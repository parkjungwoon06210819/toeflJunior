package toefadm.dto.HompageDto.NoticeDto;

import lombok.Data;

@Data
public class NewslaterDto {
		private String	dnType ;
		private int	dnCode ;
		private String	category ;
		private String	dnTitle ;
		private String	dnContent ;
		private String	dnStatus ;
		private String	dnName ;
		private String	dnRegdate ;
		private String	dnInsertPc ;
		private String	dnUpdateUserid ;
		private String	dnLastdate ;
		private String	dnUpdatePc ;
		private String	dnViewCnt ;
		private String	dnFilename ;
		private String	dnFilename2 ;


}
