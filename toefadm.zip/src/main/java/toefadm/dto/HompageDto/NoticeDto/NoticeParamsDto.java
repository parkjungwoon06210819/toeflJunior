package toefadm.dto.HompageDto.NoticeDto;


import lombok.Data;

@Data
public class NoticeParamsDto {

    private String	dnStatus ;
 }
