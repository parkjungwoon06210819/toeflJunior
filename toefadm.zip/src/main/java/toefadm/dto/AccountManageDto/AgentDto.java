package toefadm.dto.AccountManageDto;

import lombok.Data;

@Data
public class AgentDto {

	private int dacCode;
	private String dacName;
	private String dacArea;
	private String dacRegionDetail;
	private String dacCompanyYn;
	private String dacOfficeNumber;
	private String dacCeoName;
	private String dacCondition;
	private String dacType;
	private String dacZipcode;
	private String dacAddress;
	private String dacAddress2;
	private String dacCeoTel;
	private String dacCeoHp;
	private String dacMobileProvider;
	private String dacFaxNo;
	private String dacCeoEmail;
	private String dacStartDate;
	private String dacEndDate;
	private String dacMemo;
	private String dacRegdate;
	private String dacLastdate;
	private String dacCorporationNum;


}
