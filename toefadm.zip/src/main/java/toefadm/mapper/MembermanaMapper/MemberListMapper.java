package toefadm.mapper.MembermanaMapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import toefadm.dto.MembermanaDto.MemberListDto;

@Mapper
public interface MemberListMapper {
	List<MemberListDto> selectMemberList() throws Exception;
	
}
