package toefadm.mapper.MembermanaMapper;

import org.apache.ibatis.annotations.Mapper;
import toefadm.dto.MembermanaDto.GmemberListDto;

import java.util.List;

@Mapper
public interface GmemberListMapper {
	List<GmemberListDto> selectGmemberList() throws Exception;
	
}
