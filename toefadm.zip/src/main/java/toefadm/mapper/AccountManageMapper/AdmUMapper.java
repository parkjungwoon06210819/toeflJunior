package toefadm.mapper.AccountManageMapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import toefadm.dto.AccountManageDto.AdmUDto;

@Mapper
public interface AdmUMapper {
	List<AdmUDto> selectAdmUList() throws Exception;
	
}
