package toefadm.mapper.HompageMapper;

import org.apache.ibatis.annotations.Mapper;
import toefadm.dto.HompageDto.NoticeDto.NewslaterDto;

import java.util.List;

@Mapper
public interface NewslaterMapper {
	List<NewslaterDto> selectNeweslaterList() throws Exception;

}

