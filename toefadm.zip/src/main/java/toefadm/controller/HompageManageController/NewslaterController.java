package toefadm.controller.HompageManageController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import toefadm.dto.HompageDto.NoticeDto.NewslaterDto;
import toefadm.service.HompageService.NewslaterServiceImpl;
import io.swagger.annotations.ApiImplicitParam;



import java.util.List;
/**
 * 홈페이지 관리 - 뉴스레터
 * @author 박정운
 *
 */

@Api(tags = {"4. 뉴스레터 관리"})
@RequiredArgsConstructor
@RestController
@RequestMapping(value="/api/neweslaterList", method=RequestMethod.GET)
public class NewslaterController {

	@Autowired
	private NewslaterServiceImpl NewslaterService;



	@ApiOperation(value = "뉴스레터 조회", notes = "모든 뉴스레터를 조회한다.")
	@GetMapping(value = "/find")
	public List<NewslaterDto> openneweslaterList() throws Exception{
		return NewslaterService.selectNeweslaterList();
	}
}
