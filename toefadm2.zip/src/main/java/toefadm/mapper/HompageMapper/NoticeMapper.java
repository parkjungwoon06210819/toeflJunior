package toefadm.mapper.HompageMapper;

import org.apache.ibatis.annotations.Mapper;
import toefadm.dto.HompageDto.NoticeDto.NoticeDto;
import toefadm.dto.HompageDto.NoticeDto.NoticeParamsDto;


import java.util.List;

@Mapper
public interface NoticeMapper {
	List<NoticeDto> selectNoticeList() throws Exception;

	List<NoticeParamsDto> findItemMainList(NoticeParamsDto params);
}

