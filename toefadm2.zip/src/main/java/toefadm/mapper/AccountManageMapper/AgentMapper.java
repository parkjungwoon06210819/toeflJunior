package toefadm.mapper.AccountManageMapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import toefadm.dto.AccountManageDto.AgentDto;

@Mapper
public interface AgentMapper {
	List<AgentDto> selectAgentList() throws Exception;
	
}
