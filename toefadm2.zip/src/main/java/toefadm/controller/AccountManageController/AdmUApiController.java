package toefadm.controller.AccountManageController;


import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import toefadm.dto.AccountManageDto.AdmUDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import toefadm.service.AccountmanageService.AdmUServiceImpl;

/**
 * 계정 관리 - 직원관리
 * @author 박정운
 *
 */

@Api(tags = {"1. 직원 관리"})
@RequiredArgsConstructor
@RestController
@RequestMapping(value="/api/admuser", method=RequestMethod.GET)
public class AdmUApiController {
    @Autowired
    private AdmUServiceImpl admUService;

    @ApiOperation(value = "직원 조회", notes = "모든 직원을 조회한다.")
    @GetMapping(value = "/find")
    public List<AdmUDto> openAdmuserList() throws Exception{
        return admUService.selectAdmUList();
    }


}
