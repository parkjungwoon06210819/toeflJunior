package toefadm.controller.AccountManageController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import toefadm.dto.AccountManageDto.AgentDto;
import toefadm.service.AccountmanageService.AgentServiceImpl;

import java.util.List;

/**
 * 계정 관리 - 총판관리(지역본부관리)
 * @author 박정운
 *
 */
@Api(tags = {"2. 총판 관리"})
@RestController
@RequestMapping(value="/api/agentList", method=RequestMethod.GET)
public class AgentController {

	@Autowired
	private AgentServiceImpl agentService;

	@ApiOperation(value = "총판 조회", notes = "모든 총판을 조회한다.")
	@GetMapping(value = "/find")
	public List<AgentDto> openagentList() throws Exception{
		return agentService.selectAgentList();
	}
}
