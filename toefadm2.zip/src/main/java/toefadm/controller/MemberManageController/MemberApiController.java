package toefadm.controller.MemberManageController;

import java.util.List;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import toefadm.dto.MembermanaDto.MemberListDto;
import toefadm.service.MembermanaService.MemberListServiceImpl;
/**
 * 회원 관리 - 개인회원
 * @author 박정운
 *
 */

@Api(tags = {"10. 개인회원 관리"})
@RequiredArgsConstructor
@RestController
@RequestMapping(value="/api/MemberList", method=RequestMethod.GET)
public class MemberApiController {
	@Autowired
	private MemberListServiceImpl memberListService;

	@ApiOperation(value = "개인회원 조회", notes = "모든 개인회원을 조회한다.")
	@GetMapping(value = "/find")
	public List<MemberListDto> openMemberList() throws Exception{
		return memberListService.selectMemberList();
	}


}

