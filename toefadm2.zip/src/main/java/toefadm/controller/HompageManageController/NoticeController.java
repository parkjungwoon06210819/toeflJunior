package toefadm.controller.HompageManageController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import toefadm.dto.HompageDto.NoticeDto.NoticeDto;
import toefadm.dto.HompageDto.NoticeDto.NoticeParamsDto;
import toefadm.service.HompageService.NoticetServiceImpl;

import java.util.List;

/**
 * 홈페이지 관리 - 공지사항
 * @author 박정운
 *
 */

@Api(tags = {"3. 공지사항 관리"})
@RequiredArgsConstructor
@RestController
@RequestMapping(value="/api/noticeList", method=RequestMethod.GET)
public class NoticeController {

	@Autowired
	private NoticetServiceImpl NoticetService;

	@ApiOperation(value = "공지사항 조회", notes = "모든 공지사항을 조회한다.")
	@GetMapping(value = "/find")
	public List<NoticeDto> opennoticeList() throws Exception{
		return NoticetService.selectNoticeList();
	}

	@ApiOperation(value = "공지사항 검색 조회", notes = "모든 공지사항을 검색 조회한다.")
	@GetMapping(value = "/find/search")
	public List<NoticeParamsDto> findnoticeMainList(@ModelAttribute NoticeParamsDto params)throws Exception {
		// System.out.println(params.getDnStatus());
		return NoticetService.findItemMainList(params);
	}

}
