package toefadm.dto.MembermanaDto;

import lombok.Data;

@Data
public class MemberListDto {
		private int dmCode ;
		private  String dmuserid ;
		private String dmName ;
		private String dmPassword ;
		private String dmCountryType ;
		private String nationCode ;
		private String dmEnName ;
		private String dmBirthday ;
		private String dmGender ;
		private String dmRegDate ;
		private String dmEmail ;
		private String dmTel ;
		private String dmHp ;
		private String dmProvider ;
		private String dmZipcode ;
		private String dmAddress ;
		private String dmAddress2 ;
		private String dmEmailState ;
		private String dmSmsState ;
		private String dmOutDate ;
		private String leaveReasonType;
		private String dmOutMemo ;
		private String dmConnectTime ;
		private String dmMemo ;
		private String unusechk ;
		private String unusechkDate ;
		private String passwordSha2 ;
		private String 	dmConnectPc ;

}
