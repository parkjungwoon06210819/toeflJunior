package toefadm.dto.HompageDto.NoticeDto;


import lombok.Data;

@Data
public class NoticeParamsDto {

    private String psearchType;    /*검색 구분 제목 / 내용*/
    private String usearchType;    /*검색 구분 ID Name*/
    private String psearchKeyword; /*검색 키워드 */
    private String usearchKeyword; /* 사용자  키워드 */
    private String psearchStartDate; /*날짜 검색*/
    private String psearchEndDate;  /*날짜 종료일 검색*/

    private String pnoticeNo;           /*공지사항 번호*/
    private String	dnStatus ;        /*상태값 처리*/

 }
