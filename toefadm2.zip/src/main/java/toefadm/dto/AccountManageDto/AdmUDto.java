package toefadm.dto.AccountManageDto;

import lombok.Data;

@Data
public class AdmUDto {

	private int dtuUserNo;

	private String dtuLoginId;

	private String dtuPassword;

	private String dtuUserName;

	private String dtuEmail;

	private String dtuTelNum;

	private String dtuCellNum;

	private String dtuDescription;

	private String dtuStatusCd;

	private String dtuRoleno;

	private String dtuUserDept;

	private String dtuUserPosition;

	private String dtuDateSign;

	private String dtuDateReSign;

	private String dtuRegdate;

	private String dtuLastdate;
}
