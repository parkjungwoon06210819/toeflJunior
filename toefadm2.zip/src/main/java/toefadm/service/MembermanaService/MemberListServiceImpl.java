package toefadm.service.MembermanaService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import toefadm.dto.MembermanaDto.MemberListDto;
import toefadm.mapper.MembermanaMapper.MemberListMapper;

@Service
public class MemberListServiceImpl {
	
	@Autowired
	private MemberListMapper memberListMapper;
	
	public List<MemberListDto> selectMemberList() throws Exception {
		return memberListMapper.selectMemberList();
	}

}	

