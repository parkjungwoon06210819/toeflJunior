package toefadm.service.MembermanaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import toefadm.dto.MembermanaDto.GmemberListDto;
import toefadm.mapper.MembermanaMapper.GmemberListMapper;


import java.util.List;

@Service
public class GmemberListServiceImpl {
	
	@Autowired
	private GmemberListMapper gmemberListMapper;
	
	public List<GmemberListDto> selectGmemberList() throws Exception {
		return gmemberListMapper.selectGmemberList();
	}

}	

